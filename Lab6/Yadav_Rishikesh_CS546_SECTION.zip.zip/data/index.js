const restaurantData = require('./restaurants');
const reviewsData = require('./reviews');

module.exports = {
  restaurant: restaurantData,
  review: reviewsData
};