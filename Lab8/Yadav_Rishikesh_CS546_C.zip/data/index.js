const searchData = require('./search');

module.exports = {
  searchData: searchData
  };